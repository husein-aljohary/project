package com.example.myapplication.User;

public class user {
    public user() {
    }
    private int carnumber;

    public int getCarnumber() {
        return carnumber;
    }

    public void setCarnumber(int carnumber) {
        this.carnumber = carnumber;
    }
}
